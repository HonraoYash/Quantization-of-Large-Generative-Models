[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/E9yD5ezm)
Write a client-server application that establishes communication between a client and a server. The client and the server communicate using stream sockets. Both applications should run on the same host computer.

The makefile provided will generate two executables: server and client.

**Start the server first:**
`.\server <port number>`

**Start the client next:**
The client needs two arguments: the server hostname (localhost) since the server is running on the same computer, and the port number on which the server is listening.

`.\client localhost <server port number>`

- The client will prompt the user to enter a message.
- The server should display the message and terminate.
- The client should receive a response from the server and terminate.
